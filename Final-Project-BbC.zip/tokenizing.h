//Name : Asia Karki
//Class: ZCC
//Student ID: 112690227 

// Tokenizing module header


#ifndef _TOKENIZING_H_
#define _TOKENIZING_H_
#include <stdio.h> //include standard I/O library
#include <string.h> //include standard string library
void tokenizing(void);
#endif