// Name : Cynthia Samaroo
// Class : ZCC
// Student number : 146524178

// FUNDAMENTALS MODULE HEADER
#ifndef _FUNDAMENTALS_H_
#define _FUNDAMENTALS_H_

// Include Standard I/O Library
#include <stdio.h>
// Include Standard String Library
#include <stdlib.h>
// Include Standard String Library
#include <string.h>

// Find the index of a character in a string,measure the length of a string and Copy a string 
void fundamentals(void);

#endif // !_FUNDAMENTALS_H_