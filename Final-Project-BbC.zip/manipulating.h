//Name : Asia Karki
//Class: ZCC
//Student ID: 112690227 

// MANIPULATING MODULE HEADER
#ifndef _MANIPULATING_H_
#define _MANIPULATING_H_
#include <stdio.h> // Include Standard I/O library
#include <string.h> // Include Standard string library

void manipulating(void);

#endif // !_MANIPULATING_H_