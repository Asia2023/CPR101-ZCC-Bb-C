// Name : Yafei Yu
// Class : ZCC
// Student Number : 128368222

// CONVERTING MODULE HEADER
#ifndef _CONVERTING_H_
#define _CONVERTING_H_
#include <stdio.h> // Include Standard I/O library
#include <string.h> // Include Standard string library
#include <stdlib.h> // Include standard string library

void converting(void);

#endif // !_CONVERTING_H_