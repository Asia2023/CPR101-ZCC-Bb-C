//Name : Asia Karki
//Class: ZCC
//Student ID: 112690227 

//MANIPULATING SOURCE
#define _CRT_SECURE_NO_WARNINGS
#define BUFFER_SIZE 80

//Include the "manipulating.h header file
#include "manipulating.h"

//V1
void manipulating(void) {

    //printing statement to start the execution process
    printf("*** Start of Concatenating Strings Demo ***\n");
    char    string1[BUFFER_SIZE];//declared a string1 array of the char type
    char    string2[BUFFER_SIZE];//declared a string2 array of the char type
    do {
        printf("Type the 1st string (q - to quit):\n");//printing directions for an input
        fgets(string1, BUFFER_SIZE, stdin);//obtaining a value for the string1 array
        string1[strlen(string1) - 1] = '\0';

        if ((strcmp(string1, "q") != 0)) {
            printf("Type the 2nd string;\n");//printing directions for a second input
            fgets(string2, BUFFER_SIZE, stdin);//obtaining a value for the string2 array
            string2[strlen(string2) - 1] = '\0';
            strcat(string1, string2);
            printf("Concatenated string is \'%s\'\n", string1);//using the concatenated process to print
        }//here exit the loop
    } while (strcmp(string1, "q") != 0);//entered a while-loop comparison if string1!=0
    printf("*** End of Concatenating Strings Demo ***\n\n");//printing statement to end the execution process

    //v2
    printf("*** Start of Comparing strings Demo ***\n");//start
    char   compare1[BUFFER_SIZE]; //comparing string size of max 80
    char   compare2[BUFFER_SIZE]; //comparing string size of max 80
    int result; // taking an variable in int type
    do {
        printf("Type the 1st string to compare (q - to quit) : \n");//print 1st string to compare
        fgets(compare1, BUFFER_SIZE, stdin);//taking value for string 1
        compare1[strlen(compare1) - 1] = '\0';
        if (strcmp(compare1, "q") != 0) {
            printf("Type the 2nd string to compare: \n"); //printing 2nd string to compare
            fgets(compare2, BUFFER_SIZE, stdin);
            compare2[strlen(compare2) - 1] = '\0';
            result = strcmp(compare1, compare2); //assigning value if string  to integer
            if (result < 0)
                printf("\'%s\' string is less than \'%s\'\n", compare1, compare2);
            else if (result == 0)
                printf("\'%s\' string is equal to \'%s\'\n", compare1, compare2);
            else
                printf("\'%s\' string is greater than \'%s\'\n", compare1, compare2);

        }
    } while (strcmp(compare1, "q") != 0);
    printf("*** End of Comparing Strings Demo ***\n\n"); //printing statement to end the execution process
}