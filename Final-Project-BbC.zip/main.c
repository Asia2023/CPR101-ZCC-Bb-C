#define _CRT_SECURE_NO_WARNINGS

#include "fundamentals.h" // include fundamentals header file
#include "manipulating.h" // include manipulating header file
#include "converting.h" // include converting header file
#include "tokenizing.h" // include tokenizing header file

int main(void)
{
	char buff[10]; // declare variable and array
	do
	{
		printf("1 - Fundamentals\n"); // display "1 - Fundamentals"
		printf("2 - Manipulation\n"); // display "2 - Manipualting"
		printf("3 - Converting\n"); // display "3 - converting"
		printf("4 - Tokenizing\n"); // display "4 - tokenizing"
		printf("0 - Exit\n"); // diaplay "0 - exit"
		printf("Which module to run? \n"); // display "Which module to run?" to instruct the user to choose an option
		fgets(buff, 10, stdin); // read input and sends to the terminal

		switch (buff[0])
		{
		case '1': fundamentals(); // case 1 call fundamental sub-process
			break;
		case '2': manipulating(); // case 2 call manipulating sub-process
			break;
		case '3': converting(); // case 3 call converting sub-process
			break;
		case '4': tokenizing(); // case 4 call tokenizing sub-process
			break;
		}

	} while (buff[0] != '0');

	return 0;
}